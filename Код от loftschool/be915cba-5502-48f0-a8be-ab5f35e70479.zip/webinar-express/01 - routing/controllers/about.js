module.exports.get = function (req, res) {
  res.render('pages/about', { title: 'About' })
}
