module.exports.get = function (req, res) {
  res.render('pages/contact', { title: 'Contact' })
}
